package apcM6Test;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import apcM6.Appointment;

class taskTest {

	@Test
	void testAppointment() {
		Appointment Appointment = new Appointment("1234567890", "01/01/2000", "This is a description that is fifty characters lng");
		assertTrue(Appointment.getId().equals("1234567890"));
		assertTrue(Appointment.getDate().equals("01/01/2000"));
		assertTrue(Appointment.getDescription().equals("This is a description that is fifty characters lng"));
	}
	
	@Test
	void testAppointmentIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678901", "01/01/2000,", "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testAppointmentIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, "01/01/2000,", "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testAppointmentDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", null, "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testAppointmentDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", "01/01/2000", "This is a description that is fifty characters lng.");
		});
	}
	
	@Test
	void testAppointmentDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", "01/01/2000", null);
		});
	}
}
