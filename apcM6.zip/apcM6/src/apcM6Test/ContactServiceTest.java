//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import apcM6.Contact;
import apcM6.ContactService;

class ContactServiceTest {

	@Test
	void testAddContact() {
		Contact contact = new Contact("1234567890", "Jan", "Jones", "6518675309", 
				"123456 Almost Fake Streets Ave");
		ContactService addContact = ContactService.add(contact);
		
		assertNotNull(addContact);
		
	}
	
	@Test
	void testRemoveContact() {
		Contact contact = new Contact("1234567890", "Jan", "Jones", "6518675309", 
				"123456 Almost Fake Streets Ave");
		ContactService removeContact = ContactService.remove(contact);
		
		assertNull(removeContact);
		
	}
}