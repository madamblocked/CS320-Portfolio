//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import apcM6.Appointment;
import apcM6.AppointmentService;

class AppointmentServiceTest {


	@Test
	void testAddAppointment() {
		Appointment appointment = new Appointment("1234567890", "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		AppointmentService addAppointment = AppointmentService.add(appointment);
		
		assertNotNull(addAppointment);
		
	}
	
	@Test
	void testRemoveTask() {
		Appointment appointment = new Appointment("1234567890", "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		AppointmentService removeAppointment = AppointmentService.remove(appointment);
		
		assertNull(removeAppointment);
		
	}
}