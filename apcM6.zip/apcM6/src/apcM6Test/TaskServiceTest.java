//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import apcM6.Task;
import apcM6.TaskService;

class TaskServiceTest {


	@Test
	void testAddTask() {
		Task task = new Task("1234567890", "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		TaskService addTask = TaskService.add(task);
		
		assertNotNull(addTask);
		
	}
	
	@Test
	void testRemoveTask() {
		Task task= new Task("1234567890", "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		TaskService addTask = TaskService.remove(task);
		
		assertNull(removeTask);
	}
}
		
	
