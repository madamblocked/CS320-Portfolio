//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import apcM6.Contact;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact("1234567890", "Jan", "Jones", "6518675309", 
				"123456 Almost Fake Streets Ave");
		assertTrue(contact.getId().equals("1234567890"));
		assertTrue(contact.getFirstName().equals("Jan"));
		assertTrue(contact.getLastName().equals("Jones"));
		assertTrue(contact.getPhone().equals("6518675309"));
		assertTrue(contact.getAddr().equals("123456 Almost Fake Streets Ave"));
	}
	
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "Jan", "Jones", "6518675309", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Jan", "Jones", "6518675309", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "JohnathonBo", "Jones", "6518675309", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", null, "Jones", "6518675309", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Jan", "JohnathonBo", "6518675309", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Jan", null, "6518675309", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Jan", "Jones", "65186753090", 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Jan", "Jones", null, 
					"123456 Almost Fake Streets Ave");
		});
	}
	
	@Test
	void testContactAddrTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Jan", "Jones", "6518675309", 
					"123456 Almost Fake Streets Aven");
		});
	}
	
	@Test
	void testContactAddrNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Jan", "Jones", "6518675309", null);
		});
	}
}