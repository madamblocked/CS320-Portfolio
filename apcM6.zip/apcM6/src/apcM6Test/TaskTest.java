//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import apcM6.Task;

class taskTest {

	@Test
	void testTask() {
		Task task = new Task("1234567890", "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		assertTrue(task.getId().equals("1234567890"));
		assertTrue(task.getName().equals("Johnathon Jones Esq."));
		assertTrue(task.getDescription().equals("This is a description that is fifty characters lng"));
	}
	
	@Test
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678901", "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testTaskIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Johnathon Jones Esq.", "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "Johnathon Jones Esqui", "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", null, "This is a description that is fifty characters lng");
		});
	}
	
	@Test
	void testTaskDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "Johnathon Jones Esq.", "This is a description that is fifty characters lng.");
		});
	}
	
	@Test
	void testTaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "Johnathon Jones Esq.", null);
		});
	}
}
