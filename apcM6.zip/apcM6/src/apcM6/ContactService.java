//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class ContactService extends Contact {

		public ContactService(String id, String firstName, String lastName, String phone, String addr) {
			super(id, firstName, lastName, phone, addr);
		}
		
	//One and only main
	public class CRUDOperation {
		public void main(String[] args) {
			List<Contact> c = new ArrayList<Contact>();
			Scanner s = new Scanner(System.in);
			int ch;
			do {
				System.out.println("1. INSERT");
				System.out.println("2. DELETE");
				System.out.println("3. UPDATE");
				System.out.println("Enter Choice");
				ch = s.nextInt();
				 
				switch(ch){
				//ADD/INSERT
				case 1:
					System.out.println("Enter ID: ");
				 	String id = s.nextLine();
				 	System.out.println("Enter First Name: ");
					String firstName = s.nextLine();
			 		System.out.println("Enter Last Name: ");
			 		String lastName = s.nextLine();
			 		System.out.println("Enter Phone Number: ");
				 	String phone = s.nextLine();
					System.out.println("Enter Address: ");
			 		String addr = s.nextLine();
			 		
			 		c.add(new Contact(id, firstName, lastName, phone, addr));
			 	break;
			 	
			 	//DELETE
				case 2:
					Iterator<Contact> i = c.iterator();
					boolean found = false;
					System.out.print("Please enter ID to Delete: ");
					id = s.nextLine();
					while(i.hasNext()) {
						Contact e = i.next();
						if(e.getId() == id) {
							i.remove();
							found = true;
						}
					}
					if(!found) {
						System.out.println("ID Not Found");
					}else {
						System.out.println("ID " + id + " deleted successfully");
					}
				break;
				
				//UPDATE
				case 3:
					found = false;
					System.out.print("Enter ID of record to Update : ");
					id = s.nextLine();
					ListIterator<Contact> li = c.listIterator();
					while(li.hasNext()) {
						Contact e = li.next();
						if(e.getId() == id) {
							System.out.println("Enter new First Name: ");
							firstName = s.nextLine();
							System.out.println("Enter new Last Name: ");
							lastName = s.nextLine();
							System.out.println("Enter new Phone Number: ");
							phone = s.nextLine();
							System.out.println("Enter new Address: ");
							addr = s.nextLine();
							li.set(new Contact(id, firstName, lastName, phone, addr));
							found = true;
						}
						if(!found) {
							System.out.println("ID Not Found");
						}else {
							System.out.println("Record for ID " + id + " updated successfully");
						}
					}
				}
			 }while(ch!=0);
		}
	}
}

