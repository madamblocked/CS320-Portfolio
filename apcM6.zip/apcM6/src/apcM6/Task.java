//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6;

public class Task {
	
	//Initialize variables
	protected String id;
	private String name;
	private String description;
	
	//Initialize constructor
	public Task(String id, String name, String description) {
	//corresponding errors if character limits null or exceeded
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
			
		this.id = id;
		this.name = name;
		this.description = description;
		}
		
	//getters
	public String getId() {
		return id;
		}
		
	public String getName() {
		return name;
		}
		
	public String getDescription() {
		return description;
		}
}

