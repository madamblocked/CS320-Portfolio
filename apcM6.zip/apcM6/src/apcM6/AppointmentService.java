//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class AppointmentService extends Appointment {

	public AppointmentService(String id, String date, String description) {
		super(id, date, description);
	}
	
//One and only main
public class CRUDOperation {
	public void main(String[] args) {
		List<Appointment> c = new ArrayList<Appointment>();
		Scanner s = new Scanner(System.in);
		int ch;
		do {
			System.out.println("1. INSERT");
			System.out.println("2. DELETE");

			System.out.println("Enter Choice");
			ch = s.nextInt();
			 
			switch(ch){
			//ADD/INSERT
			case 1:
				System.out.println("Enter ID: ");
			 	String id = s.nextLine();
			 	System.out.println("Enter Date: ");
				String date = s.nextLine();
		 		System.out.println("Enter Description: ");
		 		String description = s.nextLine();
		 		
		 		c.add(new Appointment(id, date, description));
		 	break;
		 	
		 	//DELETE
			case 2:
				Iterator<Appointment> i = c.iterator();
				boolean found = false;
				System.out.print("Please enter ID to Delete: ");
				id = s.nextLine();
				while(i.hasNext()) {
					Appointment e = i.next();
					if(e.getId() == id) {
						i.remove();
						found = true;
					}
				}
				if(!found) {
					System.out.println("ID Not Found");
				}else {
					System.out.println("ID " + id + " deleted successfully");
				}
			break;
			
			//UPDATE
			case 3:
				found = false;
				System.out.print("Enter ID of record to Update : ");
				id = s.nextLine();
				ListIterator<Appointment> li = c.listIterator();
				while(li.hasNext()) {
					Appointment e = li.next();
					if(e.getId() == id) {
						System.out.println("Enter new date: ");
						date = s.nextLine();
						System.out.println("Enter new description: ");
						description = s.nextLine();
						li.set(new Appointment(id, date, description));
						found = true;
					}
					if(!found) {
						System.out.println("ID Not Found");
					}else {
						System.out.println("Record for ID " + id + " updated successfully");
					}
				}
			}
		 }while(ch!=0);
	}
}
}

