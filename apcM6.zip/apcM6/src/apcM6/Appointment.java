//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6;

import java.util.Date;

public class Appointment {
			
		//Initialize variables
		protected String id;
		String date;
		private String description;
		
		//Initialize constructor
		public Appointment(String id, String date, String description) {
		//corresponding errors if character limits null or exceeded
			if(id == null || id.length() > 10) {
				throw new IllegalArgumentException("Invalid ID");
			}
			//FIXME date
			if(date == null || date.before(new Date())) {
				throw new IllegalArgumentException("Invalid date");
			}
			if(description == null || description.length() > 50) {
				throw new IllegalArgumentException("Invalid description");
			}
				
			this.id = id;
			this.date = date;
			this.description = description;
			}
			
		//getters
		public String getId() {
			return id;
			}
			
		public String getDate() {
			return date;
			}
			
		public String getDescription() {
			return description;
			}
	}


