//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0

package apcM6;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class TaskService extends Task {

	public TaskService(String id, String name, String description) {
		super(id, name, description);
	}
	
//One and only main
public class CRUDOperation {
	public void main(String[] args) {
		List<Task> c = new ArrayList<Task>();
		Scanner s = new Scanner(System.in);
		int ch;
		do {
			System.out.println("1. INSERT");
			System.out.println("2. DELETE");
			System.out.println("3. UPDATE");
			System.out.println("Enter Choice");
			ch = s.nextInt();
			 
			switch(ch){
			//ADD/INSERT
			case 1:
				System.out.println("Enter ID: ");
			 	String id = s.nextLine();
			 	System.out.println("Enter Name: ");
				String name = s.nextLine();
		 		System.out.println("Enter Description: ");
		 		String description = s.nextLine();
		 		
		 		c.add(new Task(id, name, description));
		 	break;
		 	
		 	//DELETE
			case 2:
				Iterator<Task> i = c.iterator();
				boolean found = false;
				System.out.print("Please enter ID to Delete: ");
				id = s.nextLine();
				while(i.hasNext()) {
					Task e = i.next();
					if(e.getId() == id) {
						i.remove();
						found = true;
					}
				}
				if(!found) {
					System.out.println("ID Not Found");
				}else {
					System.out.println("ID " + id + " deleted successfully");
				}
			break;
			
			//UPDATE
			case 3:
				found = false;
				System.out.print("Enter ID of record to Update : ");
				id = s.nextLine();
				ListIterator<Task> li = c.listIterator();
				while(li.hasNext()) {
					Task e = li.next();
					if(e.getId() == id) {
						System.out.println("Enter new name: ");
						name = s.nextLine();
						System.out.println("Enter new description: ");
						description = s.nextLine();
						li.set(new Task(id, name, description));
						found = true;
					}
					if(!found) {
						System.out.println("ID Not Found");
					}else {
						System.out.println("Record for ID " + id + " updated successfully");
					}
				}
			}
		 }while(ch!=0);
	}
}
}