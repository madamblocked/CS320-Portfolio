//Author: Adam Conger
//CS 320 SNHU
//Project 1 Version 1.0


package apcM6;

public class Contact {
	
	//Initialize variables
		protected String id;
		private String firstName;
		private String lastName;
		private String phone;
		private String addr;
		
		//Initialize constructor
		public Contact(String id, String firstName, 
				String lastName, String phone, String addr) {
			//corresponding errors if character limits null or exceeded
			if(id == null || id.length() > 10) {
				throw new IllegalArgumentException("Invalid ID");
			}
			if(firstName == null || firstName.length() > 10) {
				throw new IllegalArgumentException("Invalid first name");
			}
			if(lastName == null || lastName.length() > 10) {
				throw new IllegalArgumentException("Invalid last name");
			}
			if(phone == null || phone.length() > 10) {
				throw new IllegalArgumentException("Invalid phone number");
			}
			if(addr == null || addr.length() > 30) {
				throw new IllegalArgumentException("Invalid address");
			}
			
			this.id = id;
			this.firstName = firstName;
			this.lastName = lastName;
			this.phone = phone;
			this.addr = addr;	
		}
		
		//getters
		public String getId() {
			return id;
		}
		
		public String getFirstName() {
			return firstName;
		}
		
		public String getLastName() {
			return lastName;
		}
		
		public String getPhone() {
			return phone;
		}
		
		public String getAddr() {
			return addr;
		}


}
